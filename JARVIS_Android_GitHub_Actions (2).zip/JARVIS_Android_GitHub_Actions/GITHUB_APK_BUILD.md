# JARVIS APK with GitHub Actions
Upload this project to a GitHub repository. Then open **Actions → Build JARVIS APK → Run workflow**. After the run succeeds, open the run and download the **JARVIS-debug-APK** artifact. Extract the APK and install it on Android.
