#!/usr/bin/env python3
"""
generate_demo.py

Builds a fake-but-realistic vault of markdown notes under data/demo_vault/,
shaped like a small studio/agency's actual files: clients, projects, calls,
invoices, proposals, SOPs, people, concepts, briefs, a campaign.

Fixed random seed -> identical graph every run. Safe to screen-record.

Run: python3 generate_demo.py
"""
import random
import os
import shutil
from datetime import date, timedelta

SEED = 42
random.seed(SEED)

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "demo_vault")

# Target counts, matched to a real reference graph so the demo "feels" real
COUNTS = {
    "Call": 38,
    "Note": 29,
    "Concept": 16,
    "Project": 33,
    "Person": 19,
    "Client": 9,
    "Invoice": 9,
    "Proposal": 9,
    "Sop": 6,
    "Brief": 2,
    "Campaign": 1,
}

CLIENTS = [
    "Filect", "Northbeam Automation", "Orchard Legal", "Fairview Dental",
    "Harbour Accounting", "Halden Physio", "Vantage Property",
    "Kestrel Logistics", "Copper & Rye",
]

PEOPLE_FIRST = ["Priya", "Marcus", "Yasmin", "Nadia", "Tom", "Elena",
                "Ravi", "Jonah", "Freya", "Callum", "Amira", "Beth",
                "Oscar", "Nina", "Leo", "Sasha", "Dev", "Kim", "Aldo"]
PEOPLE_LAST = ["Raman", "Feld", "Bell", "Ochieng", "Okafor", "Voss",
               "Lindqvist", "Marchetti", "Novak", "Reyes"]

PROJECT_KINDS = ["Automation build", "Handover pack", "Discovery call",
                  "SOP — Proposal", "SOP — Handover", "SOP — Automation build",
                  "Reusable components", "Change order", "Onboarding"]

CONCEPTS = ["Growth package", "Retainer model", "Margin model", "Scope creep",
            "Handover pack", "Discovery call", "Change order", "SOP library",
            "Reusable components", "Audit process", "Onboarding checklist",
            "Pricing tiers", "Referral loop", "Churn risk", "Upsell path",
            "Fixed-fee vs retainer"]

random.shuffle(CONCEPTS)

STATUSES = ["draft", "sent", "in progress", "done", "overdue", "paid"]


def slug(s):
    return s.lower().replace(" ", "-").replace("&", "and").replace("—", "-").replace("--", "-")


def frontmatter(type_, extra=None):
    lines = ["---", f"type: {type_}"]
    if extra:
        for k, v in extra.items():
            lines.append(f"{k}: {v}")
    lines.append("---")
    return "\n".join(lines)


def write_note(name, type_, body, links=None, extra=None):
    links = links or []
    fname = f"{slug(name)}.md"
    path = os.path.join(OUT, type_.lower())
    os.makedirs(path, exist_ok=True)
    link_block = ""
    if links:
        link_block = "\n\n## Related\n" + "\n".join(f"- [[{l}]]" for l in links)
    content = f"{frontmatter(type_, extra)}\n\n# {name}\n\n{body}{link_block}\n"
    with open(os.path.join(path, fname), "w") as f:
        f.write(content)


def rand_date(days_back=180):
    return date.today() - timedelta(days=random.randint(0, days_back))


def main():
    if os.path.exists(OUT):
        shutil.rmtree(OUT)
    os.makedirs(OUT)

    all_names = {t: [] for t in COUNTS}

    # Clients
    for c in CLIENTS[:COUNTS["Client"]]:
        all_names["Client"].append(c)

    # People, roughly 1-3 per client
    people = []
    for _ in range(COUNTS["Person"]):
        name = f"{random.choice(PEOPLE_FIRST)} {random.choice(PEOPLE_LAST)}"
        if name in people:
            continue
        people.append(name)
    all_names["Person"] = people[:COUNTS["Person"]]

    # Concepts
    all_names["Concept"] = CONCEPTS[:COUNTS["Concept"]]

    # Projects, Calls, Invoices, Proposals, SOPs tied to clients
    for i in range(COUNTS["Project"]):
        client = random.choice(CLIENTS)
        kind = random.choice(PROJECT_KINDS)
        all_names["Project"].append(f"{client} — {kind} #{i+1}")

    for i in range(COUNTS["Call"]):
        client = random.choice(CLIENTS)
        all_names["Call"].append(f"Call — {client} — {rand_date().isoformat()}")

    for i in range(COUNTS["Invoice"]):
        client = random.choice(CLIENTS)
        all_names["Invoice"].append(f"Invoice — {client} #{1000+i}")

    for i in range(COUNTS["Proposal"]):
        client = random.choice(CLIENTS)
        all_names["Proposal"].append(f"Proposal — {client} #{i+1}")

    sop_names = ["SOP — Automation build", "SOP — Handover", "SOP — Proposal",
                 "SOP — Discovery call", "SOP — Change order", "SOP — Onboarding"]
    all_names["Sop"] = sop_names[:COUNTS["Sop"]]

    all_names["Brief"] = ["Brief — Q3 growth push", "Brief — referral pilot"][:COUNTS["Brief"]]
    all_names["Campaign"] = ["Campaign — Spring audit outreach"][:COUNTS["Campaign"]]

    # Notes: freeform, link back into everything else
    for i in range(COUNTS["Note"]):
        all_names["Note"].append(f"Note — {random.choice(CONCEPTS)} thoughts #{i+1}")

    # --- write files with cross-links ---

    # Pre-compute per-client groupings so entities actually reference each
    # other the way real files would (a client's page links every project,
    # call, invoice and proposal under it; those link back to the client
    # plus each other where it's natural).
    by_client = {c: {"projects": [], "calls": [], "invoices": [], "proposals": [],
                      "people": []} for c in CLIENTS}
    for p in all_names["Project"]:
        by_client[p.split(" — ")[0]]["projects"].append(p)
    for c in all_names["Call"]:
        by_client[c.split(" — ")[1]]["calls"].append(c)
    for i in all_names["Invoice"]:
        by_client[i.split(" — ")[1].split(" #")[0]]["invoices"].append(i)
    for pr in all_names["Proposal"]:
        by_client[pr.split(" — ")[1].split(" #")[0]]["proposals"].append(pr)
    for person in people:
        by_client[random.choice(CLIENTS)]["people"].append(person)

    person_client = {}
    for client, g in by_client.items():
        for person in g["people"]:
            person_client[person] = client
    # anyone left unassigned gets a client so Person nodes aren't orphaned
    for person in people:
        if person not in person_client:
            client = random.choice(CLIENTS)
            person_client[person] = client
            by_client[client]["people"].append(person)

    sop_pool = all_names["Sop"]

    for client in all_names["Client"]:
        g = by_client[client]
        links = g["people"] + g["projects"] + g["calls"] + g["invoices"] + g["proposals"]
        write_note(
            client, "Client",
            f"Client since {rand_date(400).isoformat()}. Primary contact(s) and open work below.",
            links=links,
            extra={"status": random.choice(["active", "active", "paused"])},
        )

    for person in all_names["Person"]:
        client = person_client[person]
        g = by_client[client]
        their_calls = random.sample(g["calls"], k=min(2, len(g["calls"]))) if g["calls"] else []
        write_note(
            person, "Person",
            f"Contact at [[{client}]].",
            links=[client] + their_calls,
        )

    for concept in all_names["Concept"]:
        linked_notes = random.sample(all_names["Note"], k=min(3, len(all_names["Note"])))
        linked_concepts = random.sample(
            [c for c in all_names["Concept"] if c != concept], k=min(2, len(all_names["Concept"]) - 1)
        )
        write_note(concept, "Concept", f"Working definition and notes on {concept.lower()}.",
                   links=linked_notes + linked_concepts)

    for client in all_names["Client"]:
        g = by_client[client]
        for project in g["projects"]:
            sop = random.choice(sop_pool) if sop_pool and random.random() < 0.6 else None
            related_call = random.choice(g["calls"]) if g["calls"] else None
            links = [client] + g["people"][:1]
            if sop:
                links.append(sop)
            if related_call:
                links.append(related_call)
            write_note(
                project, "Project",
                f"Status: {random.choice(STATUSES)}. For [[{client}]].",
                links=links,
                extra={"status": random.choice(STATUSES)},
            )

        for call in g["calls"]:
            person = random.choice(g["people"]) if g["people"] else random.choice(people)
            related_project = random.choice(g["projects"]) if g["projects"] and random.random() < 0.5 else None
            links = [client, person]
            if related_project:
                links.append(related_project)
            write_note(call, "Call", f"Call with {person} re: [[{client}]].", links=links)

        for invoice in g["invoices"]:
            amount = random.choice([800, 1200, 4000, 4500, 6000, 9000])
            status = random.choice(["paid", "sent", "overdue", "half-paid"])
            related_project = random.choice(g["projects"]) if g["projects"] and random.random() < 0.5 else None
            links = [client]
            if related_project:
                links.append(related_project)
            write_note(
                invoice, "Invoice",
                f"Amount: £{amount}. Status: {status}. Client: [[{client}]].",
                links=links,
                extra={"amount": amount, "status": status},
            )

        for proposal in g["proposals"]:
            related_project = random.choice(g["projects"]) if g["projects"] and random.random() < 0.5 else None
            links = [client]
            if related_project:
                links.append(related_project)
            write_note(
                proposal, "Proposal",
                f"Sent to [[{client}]]. Package: {random.choice(['Starter','Growth','Retainer'])}.",
                links=links,
            )

    for sop in all_names["Sop"]:
        write_note(sop, "Sop", f"Standard steps for {sop.replace('SOP — ', '').lower()}.")

    for brief in all_names["Brief"]:
        linked_clients = random.sample(CLIENTS, k=min(3, len(CLIENTS)))
        write_note(brief, "Brief", "Objectives, audience, deadline.", links=linked_clients)

    for campaign in all_names["Campaign"]:
        linked = random.sample(CLIENTS, k=min(4, len(CLIENTS)))
        write_note(campaign, "Campaign", "Outbound push tied to Q3 goals.", links=linked)

    for note in all_names["Note"]:
        linked = random.sample(all_names["Concept"], k=min(2, len(all_names["Concept"])))
        write_note(note, "Note", "Freeform working note.", links=linked)

    total = sum(len(v) for v in all_names.values())
    print(f"Generated {total} notes under {OUT} (seed={SEED})")
    for t, names in all_names.items():
        print(f"  {t}: {len(names)}")


if __name__ == "__main__":
    main()
