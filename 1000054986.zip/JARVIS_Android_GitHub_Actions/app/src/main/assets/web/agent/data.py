"""
data.py — THE ONLY FILE THAT TOUCHES MY REAL DATA.

JARVIS_DEMO controls everything:
  1 (default) -> demo fixtures, safe to screen-record
  0           -> real folders below

Change VAULT_PATHS_REAL to point at your own folders. Nothing else in the
codebase should ever reference a real filesystem path directly — it all
comes through here.
"""
import os

DEMO = os.environ.get("JARVIS_DEMO", "1") != "0"

HERE = os.path.dirname(os.path.abspath(__file__))
VAULT_PATH_DEMO = os.path.join(HERE, "..", "data", "demo_vault")

# --- Fill these in with your real folders when you're ready for JARVIS_DEMO=0 ---
VAULT_PATHS_REAL = [
    # "/Users/daksh/Documents/Clients",
    # "/Users/daksh/Notes",
]


def get_vault_paths():
    if DEMO:
        return [VAULT_PATH_DEMO]
    if not VAULT_PATHS_REAL:
        raise RuntimeError(
            "JARVIS_DEMO=0 but VAULT_PATHS_REAL is empty in agent/data.py. "
            "Add your real folder paths there first."
        )
    return VAULT_PATHS_REAL


# --------------------------------------------------------------------------
# Business context — used by research_web to land external numbers back on
# yours, and by the system prompt (prompt.md) for tone/identity.
#
# STILL PLACEHOLDER. You never sent real numbers, so these are generic
# stand-ins — replace them before this says anything to a client-facing
# situation. Nothing here is invented as fact anywhere else in the app;
# it's only used as context for the model, and only in DEMO mode.
# --------------------------------------------------------------------------
BUSINESS = {
    "owner_name": "Daksh",
    "business": "PLACEHOLDER — you haven't told me what the business is yet.",
    "offers": "PLACEHOLDER — no real pricing given yet.",
    "tone_notes": "PLACEHOLDER — no speaking-style preferences given yet. "
                   "Defaulting to short, direct, no filler, no 'Great question.'",
}


# --------------------------------------------------------------------------
# Inbox / calendar — DEMO ONLY.
#
# read_inbox and brief_me need a real integration (Gmail/Outlook API,
# Google/Apple Calendar) to mean anything against your real life — that's
# an OAuth flow and a new dependency, neither of which I've built or asked
# you to install. In JARVIS_DEMO=0 these two tools say so and stop, rather
# than pretending to read an inbox that was never connected.
# --------------------------------------------------------------------------
DEMO_INBOX = [
    {"from": "Amira Feld", "subject": "Re: Growth package — timing", "unread": True,
     "preview": "Thursday or Friday both work for the audit call."},
    {"from": "Elena Lindqvist", "subject": "Invoice #1006", "unread": True,
     "preview": "Can you resend this — think it bounced from finance."},
    {"from": "Jonah Novak", "subject": "Handover pack", "unread": False,
     "preview": "Got it, thanks — looks complete."},
    {"from": "A vendor nobody's heard of", "subject": "Automation SaaS demo?", "unread": True,
     "preview": "Following up on my note last week — got 15 min this week?"},
]

DEMO_CALENDAR = [
    {"time": "10:00", "title": "Discovery call — Kestrel Logistics"},
    {"time": "14:30", "title": "Audit review — Filect"},
    {"time": "16:00", "title": "Internal — pipeline review"},
]


def get_business():
    return BUSINESS


def get_inbox():
    if not DEMO:
        raise RuntimeError("read_inbox needs a real email integration — not built yet.")
    return DEMO_INBOX


def get_calendar():
    if not DEMO:
        raise RuntimeError("brief_me needs a real calendar integration — not built yet.")
    return DEMO_CALENDAR
