"""
memory.py — writes to memory/ and nowhere else.

One dated markdown file per remembered fact. Never overwrites, never
deletes, never touches any path outside memory/. This is the only file
in the codebase that calls open(..., "w").
"""
import os
import re
import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
MEMORY_DIR = os.path.join(HERE, "..", "memory")


def _slug(s):
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")[:60]


def remember(fact_text):
    """
    Writes one markdown file to memory/, named by date + a slug of the
    fact. Returns the filename and the exact content written, so the
    caller can say out loud exactly what got saved (never write silently).
    """
    os.makedirs(MEMORY_DIR, exist_ok=True)
    today = datetime.date.today().isoformat()
    slug = _slug(fact_text) or "note"
    base = f"{today}-{slug}"
    fname = base + ".md"
    path = os.path.join(MEMORY_DIR, fname)
    n = 2
    while os.path.exists(path):
        fname = f"{base}-{n}.md"
        path = os.path.join(MEMORY_DIR, fname)
        n += 1

    content = f"---\ndate: {today}\n---\n\n{fact_text.strip()}\n"
    with open(path, "w") as f:
        f.write(content)
    return fname, content


def list_memories():
    if not os.path.isdir(MEMORY_DIR):
        return []
    return sorted(f for f in os.listdir(MEMORY_DIR) if f.endswith(".md"))


def read_all_memories():
    """Used to fold prior remembered facts into the system prompt context."""
    out = []
    for fname in list_memories():
        try:
            with open(os.path.join(MEMORY_DIR, fname), "r") as f:
                out.append((fname, f.read()))
        except OSError:
            continue
    return out
