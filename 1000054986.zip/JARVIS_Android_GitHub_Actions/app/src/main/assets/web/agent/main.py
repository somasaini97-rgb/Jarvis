"""
main.py — HTTP server + API.

Stdlib only (http.server, urllib). Serves the static ui/ folder, the
/api/graph JSON the browser renders on load, and /api/ask which routes
each message to conversation or a tool, via OpenAI when a key is present
and a keyword fallback when it isn't (routing must work without a model).

Run: python3 agent/main.py
Then open http://localhost:8420

To reach it from your phone on the same WiFi, set JARVIS_HOST=0.0.0.0 in
.env first — see README.md's "Access from your phone" section. This opens
the server to your whole local network, not just this machine, so only do
it on WiFi you trust.
"""
import json
import os
import re
import socket
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import llm
llm.load_dotenv(os.path.join(HERE, "..", ".env"))  # must happen before data.py reads JARVIS_DEMO

import data
import vault
import tools as tools_module

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PORT = int(os.environ.get("JARVIS_PORT", "8420"))
# localhost = only this machine. 0.0.0.0 = reachable from other devices on
# your WiFi (your phone, say) — see the docstring above before turning this on.
HOST = os.environ.get("JARVIS_HOST", "localhost")
UI_DIR = os.path.join(HERE, "..", "ui")
PROMPT_PATH = os.path.join(HERE, "prompt.md")

MAX_HISTORY_TURNS = 10  # ~10 turns = up to 20 messages (user+assistant)

# ---------------------------------------------------------------- index ----
_nodes = None
_stats = None
_tools = None


def build_index():
    global _nodes, _stats, _tools
    paths = data.get_vault_paths()
    _nodes, _stats = vault.build_graph(paths)
    _tools = tools_module.Tools(_nodes)


def get_graph_payload():
    return {
        "mode": "DEMO" if data.DEMO else "REAL",
        "stats": _stats,
        "nodes": [
            {
                "id": n.id, "title": n.title, "type": n.type,
                "degree": n.degree, "preview": n.body_preview, "path": n.path,
            }
            for n in _nodes.values()
        ],
        "edges": [[a, b] for a, b in _edges_from(_nodes)],
    }


def _edges_from(nodes):
    seen = set()
    for n in nodes.values():
        for target in n.links_out:
            key = tuple(sorted((n.id, target)))
            if key in seen:
                continue
            seen.add(key)
            yield key


# ------------------------------------------------------------- prompt.md ---
def render_system_prompt():
    with open(PROMPT_PATH, "r") as f:
        template = f.read()
    biz = data.get_business()
    business_context = (
        f"{biz['owner_name']} — {biz['business']}\n"
        f"What they sell: {biz['offers']}"
    )
    return template.replace("{business_context}", business_context) \
                    .replace("{tone_notes}", biz["tone_notes"])


# ------------------------------------------------------------- conversation
# Single local user, no auth — one in-memory history is fine.
_history = []


def trim_history():
    max_msgs = MAX_HISTORY_TURNS * 2
    if len(_history) > max_msgs:
        del _history[: len(_history) - max_msgs]


GREETING_RE = re.compile(
    r"^\s*(hi|hey|hello|yo|sup|hiya)\b|can you hear me|you there\??$", re.IGNORECASE
)


def fallback_route(message):
    """No model reachable — decide between conversation and a tool by
    scoring the message against keywords and the vault itself, never by
    pretending a model made the call."""
    text = message.lower().strip()

    if GREETING_RE.search(text):
        return {"speak": "Yep, here. No model connected though — keyword routing only.",
                "card": None}

    if any(w in text for w in ("remember", "note that", "save this", "make a note")):
        return _tools.remember(message)
    if "brief" in text:
        return _tools.brief_me()
    if "plan" in text and ("day" in text or "today" in text):
        return _tools.plan_day()
    if any(w in text for w in ("inbox", "unread", "email", "messages")):
        return _tools.read_inbox()

    results = vault.search(_nodes, message, limit=1)
    if results:
        return _tools.search_brain(message)

    return {
        "speak": "No model connected, so I'm limited to keyword matching — nothing matched.",
        "card": {"tool": None, "note": "Add OPENAI_API_KEY to .env for real conversation and routing."},
    }


def model_route(message):
    system = {"role": "system", "content": render_system_prompt()}
    messages = [system] + _history + [{"role": "user", "content": message}]

    reply = llm.chat(messages, tools=tools_module.TOOL_SCHEMAS, tool_choice="auto")

    tool_calls = reply.get("tool_calls")
    if not tool_calls:
        return {"speak": (reply.get("content") or "").strip(), "card": None}

    call = tool_calls[0]
    name = call["function"]["name"]
    try:
        args = json.loads(call["function"]["arguments"] or "{}")
    except json.JSONDecodeError:
        args = {}

    fn = getattr(_tools, name, None)
    if fn is None:
        return {"speak": f"Model asked for an unknown tool: {name}.", "card": None}

    if name == "research_web":
        return fn(args.get("query", message), ai_call=llm.simple_text)
    if name == "search_brain":
        return fn(args.get("query", message))
    if name == "remember":
        return fn(args.get("fact", message))
    return fn()  # read_inbox / brief_me / plan_day take no args


def handle_ask(message):
    model_missing = not llm.api_key_present()
    try:
        if model_missing:
            raise RuntimeError("no key")
        result = model_route(message)
    except Exception:
        model_missing = True
        result = fallback_route(message)

    _history.append({"role": "user", "content": message})
    _history.append({"role": "assistant", "content": result["speak"]})
    trim_history()

    result = dict(result)
    result["model_missing"] = model_missing
    return result


# --------------------------------------------------------------- server ---
SAFE_STATIC = {
    "/": "index.html",
    "/index.html": "index.html",
    "/app.js": "app.js",
    "/graph.js": "graph.js",
    "/styles.css": "styles.css",
}
CONTENT_TYPES = {
    ".html": "text/html; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".json": "application/json; charset=utf-8",
}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        print(f"[jarvis] {self.address_string()} - {fmt % args}")

    def _send_json(self, obj, status=200):
        body = json.dumps(obj).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_file(self, relpath):
        full = os.path.join(UI_DIR, relpath)
        if not os.path.abspath(full).startswith(os.path.abspath(UI_DIR)):
            self.send_error(403); return
        if not os.path.isfile(full):
            self.send_error(404); return
        ext = os.path.splitext(full)[1]
        with open(full, "rb") as f:
            body = f.read()
        self.send_response(200)
        self.send_header("Content-Type", CONTENT_TYPES.get(ext, "application/octet-stream"))
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/api/graph":
            try:
                self._send_json(get_graph_payload())
            except Exception as e:
                self._send_json({"error": str(e)}, status=500)
            return
        if self.path == "/api/memories":
            try:
                import memory as memory_module
                entries = memory_module.read_all_memories()
                self._send_json({"memories": [{"file": f, "content": c} for f, c in entries]})
            except Exception as e:
                self._send_json({"error": str(e)}, status=500)
            return
        if self.path in SAFE_STATIC:
            self._send_file(SAFE_STATIC[self.path])
            return
        self.send_error(404)

    def do_POST(self):
        if self.path != "/api/ask":
            self.send_error(404)
            return
        length = int(self.headers.get("Content-Length", 0))
        raw = self.rfile.read(length) if length else b"{}"
        try:
            payload = json.loads(raw.decode("utf-8"))
            message = (payload.get("message") or "").strip()
        except (json.JSONDecodeError, UnicodeDecodeError):
            self._send_json({"error": "bad request"}, status=400)
            return
        if not message:
            self._send_json({"error": "empty message"}, status=400)
            return
        try:
            result = handle_ask(message)
            self._send_json(result)
        except Exception as e:
            self._send_json({"speak": "Something broke on the server side.",
                              "card": {"error": str(e)}, "model_missing": True}, status=500)


def _lan_ip():
    """Best-effort local network IP, for printing a phone-reachable URL."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))  # no packet actually sent, just picks the right interface
        ip = s.getsockname()[0]
        s.close()
        return ip
    except OSError:
        return None


def main():
    build_index()
    mode = "DEMO" if data.DEMO else "REAL"
    print(f"[jarvis] mode={mode}")
    print(f"[jarvis] indexed {_stats['total_nodes']} notes")
    print(f"[jarvis] model: {'OpenAI (' + llm.MODEL + ')' if llm.api_key_present() else 'NOT CONNECTED — keyword fallback only. Add OPENAI_API_KEY to .env.'}")
    print(f"[jarvis] serving on http://localhost:{PORT}")
    if HOST == "0.0.0.0":
        lan_ip = _lan_ip()
        if lan_ip:
            print(f"[jarvis] also reachable on your WiFi at http://{lan_ip}:{PORT} — that's the URL for your phone")
        print("[jarvis] JARVIS_HOST=0.0.0.0 — this server is open to your whole local network.")
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n[jarvis] shutting down")


if __name__ == "__main__":
    main()
