/* app.js — step 3: graph UI + conversation/tools. No voice yet (step 4). */
(function () {
  const TYPE_ORDER = ["Call", "Note", "Concept", "Project", "Person", "Client",
                       "Invoice", "Proposal", "Sop", "Brief", "Campaign"];

  const EXAMPLE_PROMPTS = [
    "What's the status on Filect?",
    "Brief me.",
    "What's in my inbox?",
    "Plan my day.",
  ];

  const canvas = document.getElementById("graph-canvas");
  const statusBanner = document.getElementById("status-banner");
  const modeBadge = document.getElementById("mode-badge");
  const inspectorBody = document.getElementById("inspector-body");
  const inspectorPanel = document.getElementById("inspector");
  const hubsList = document.getElementById("hubs-list");
  const filterList = document.getElementById("filter-list");
  const examplePromptEl = document.getElementById("example-prompt");
  const captionEl = document.getElementById("caption");
  const askInput = document.getElementById("ask-input");
  const reactorRing = document.getElementById("reactor-ring");
  const reactorStatus = document.getElementById("reactor-status");

  let graphHandle = null;
  let bannerTimer = null;

  function showBanner(msg, persist) {
    statusBanner.textContent = msg;
    statusBanner.classList.add("show");
    clearTimeout(bannerTimer);
    if (!persist) bannerTimer = setTimeout(() => statusBanner.classList.remove("show"), 4000);
  }

  function escapeHtml(s) {
    const d = document.createElement("div");
    d.textContent = s == null ? "" : String(s);
    return d.innerHTML;
  }

  function setReactorState(state) {
    reactorRing.className = state ? `state-${state}` : "";
    reactorStatus.textContent = state || "idle";
  }

  // ---- inspector: node focus (from the graph) ----
  function renderInspector(node) {
    if (!node) {
      inspectorBody.innerHTML =
        '<p class="empty-hint">Click a node to focus it. Shift-click a second to trace the path.</p>';
      inspectorPanel.classList.remove("sheet-open");
      return;
    }
    inspectorPanel.classList.add("sheet-open");
    inspectorBody.innerHTML = `
      <div class="note-title">${escapeHtml(node.title)}</div>
      <div class="note-type">${escapeHtml(node.type)}</div>
      <div class="note-preview">${escapeHtml(node.preview || "No preview available.")}</div>
      <div class="note-path">${escapeHtml(node.path || "")}</div>
    `;
  }

  function renderPathTrace(pathNodes) {
    if (!pathNodes) return;
    inspectorPanel.classList.add("sheet-open");
    inspectorBody.innerHTML =
      '<div class="note-title">Path</div><div class="note-preview">' +
      pathNodes.map((n) => escapeHtml(n.title)).join(" &rarr; ") +
      "</div>";
  }

  // ---- inspector: tool result cards (from /api/ask) ----
  function renderToolCard(card) {
    inspectorPanel.classList.add("sheet-open");
    if (!card || !card.tool) {
      inspectorBody.innerHTML = '<p class="empty-hint">Nothing to show for that.</p>';
      return;
    }
    let html = `<div class="note-title">${escapeHtml(prettyToolName(card.tool))}</div>`;

    if (card.tool === "search_brain") {
      html += (card.results || []).map((r) => `
        <div style="margin-top:10px;">
          <div style="font-size:12.5px;font-weight:600;">${escapeHtml(r.title)}
            <span class="note-type" style="margin-left:6px;">${escapeHtml(r.type)}</span>
          </div>
          <div class="note-preview">${escapeHtml(r.snippet)}</div>
        </div>`).join("") || '<p class="note-preview">No matches.</p>';
    } else if (card.tool === "research_web") {
      html += `<div class="note-preview">${escapeHtml(card.answer)}</div>`;
      if (card.note) html += `<div class="note-path">${escapeHtml(card.note)}</div>`;
    } else if (card.tool === "read_inbox") {
      html += (card.messages || []).map((m) => `
        <div style="margin-top:10px;">
          <div style="font-size:12.5px;font-weight:600;">${escapeHtml(m.from)}
            ${m.known_contact ? '<span class="note-type" style="margin-left:6px;">in your files</span>' : ""}
          </div>
          <div class="note-preview">${escapeHtml(m.subject)} — ${escapeHtml(m.preview)}</div>
        </div>`).join("") || '<p class="note-preview">Inbox is clear.</p>';
    } else if (card.tool === "brief_me") {
      html += `<div class="note-preview">${(card.calendar || []).map(c => `${escapeHtml(c.time)} — ${escapeHtml(c.title)}`).join("<br/>")}</div>`;
      if (card.overdue_invoices && card.overdue_invoices.length) {
        html += `<div class="note-title" style="margin-top:10px;font-size:12px;">Overdue</div>`;
        html += `<div class="note-preview">${card.overdue_invoices.map(i => escapeHtml(i.title)).join("<br/>")}</div>`;
      }
    } else if (card.tool === "plan_day") {
      html += `<div class="note-preview">${(card.items || []).map((it, i) => `${i + 1}. ${escapeHtml(it.label)}`).join("<br/>")}</div>`;
    } else if (card.tool === "remember") {
      html += `<div class="note-preview">${escapeHtml(card.content)}</div>`;
    } else if (card.error) {
      html += `<div class="note-preview">${escapeHtml(card.error)}</div>`;
    }
    inspectorBody.innerHTML = html;
  }

  function prettyToolName(tool) {
    return { search_brain: "Search", research_web: "Research", read_inbox: "Inbox",
             brief_me: "Brief", plan_day: "Plan", remember: "Remembered" }[tool] || tool;
  }

  function renderHubs(nodes, handle) {
    const top = [...nodes].sort((a, b) => (b.degree || 0) - (a.degree || 0)).slice(0, 8);
    hubsList.innerHTML = "";
    for (const n of top) {
      const row = document.createElement("div");
      row.className = "hub-row";
      row.innerHTML = `<span class="hub-dot" style="background:${window.JarvisGraph.colorFor(n.type)}"></span>
        <span class="hub-name">${escapeHtml(n.title)}</span>
        <span class="hub-count">${n.degree || 0}</span>`;
      row.addEventListener("click", () => handle.focusById(n.id));
      hubsList.appendChild(row);
    }
  }

  function renderFilters(nodes) {
    const counts = {};
    for (const t of TYPE_ORDER) counts[t] = 0;
    for (const n of nodes) counts[n.type] = (counts[n.type] || 0) + 1;

    filterList.innerHTML = "";
    for (const t of TYPE_ORDER) {
      if (!(t in counts)) continue;
      const row = document.createElement("div");
      row.className = "filter-row";
      row.dataset.type = t;
      row.innerHTML = `<span class="fdot" style="background:${window.JarvisGraph.colorFor(t)}"></span>
        <span class="fname">${t}</span>
        <span class="fcount">${counts[t]}</span>`;
      filterList.appendChild(row);
    }
  }

  function rotateExamplePrompt() {
    let i = 0;
    examplePromptEl.textContent = `try: "${EXAMPLE_PROMPTS[0]}"`;
    setInterval(() => {
      i = (i + 1) % EXAMPLE_PROMPTS.length;
      examplePromptEl.textContent = `try: "${EXAMPLE_PROMPTS[i]}"`;
    }, 5000);
  }

  // ---- conversation ----
  async function ask(message) {
    if (!message.trim()) return;
    askInput.value = "";
    setReactorState("thinking");
    captionEl.textContent = "";
    try {
      const res = await fetch("/api/ask", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message }),
      });
      const result = await res.json();
      setReactorState("speaking");
      captionEl.textContent = result.speak || "";
      if (result.card) renderToolCard(result.card);
      if (result.model_missing) {
        showBanner("No model connected — running on keyword routing only. Add OPENAI_API_KEY to .env.", true);
      } else {
        statusBanner.classList.remove("show");
      }
      setTimeout(() => {
        setReactorState(null);
        captionEl.textContent = "";
      }, 4500);
    } catch (err) {
      setReactorState(null);
      showBanner("Can't reach the JARVIS server.");
    }
  }

  function wireButtons() {
    askInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") ask(askInput.value);
    });
    document.getElementById("brief-btn").addEventListener("click", () => ask("brief me"));
    document.getElementById("plan-btn").addEventListener("click", () => ask("plan my day"));
    document.getElementById("memory-btn").addEventListener("click", async () => {
      inspectorPanel.classList.add("sheet-open");
      inspectorBody.innerHTML = '<p class="empty-hint">Loading memory…</p>';
      try {
        const res = await fetch("/api/memories");
        const data = await res.json();
        if (!data.memories || !data.memories.length) {
          inspectorBody.innerHTML = '<p class="empty-hint">Nothing remembered yet.</p>';
          return;
        }
        inspectorBody.innerHTML = '<div class="note-title">Memory</div>' +
          data.memories.slice().reverse().map((m) =>
            `<div style="margin-top:8px;"><div class="note-path">${escapeHtml(m.file)}</div>
             <div class="note-preview">${escapeHtml(m.content.split("\n").slice(3).join(" ").trim())}</div></div>`
          ).join("");
      } catch (e) {
        inspectorBody.innerHTML = '<p class="empty-hint">Couldn\'t reach the server.</p>';
      }
    });
    // Voice isn't built yet (step 4) — these degrade loudly rather than doing nothing.
    const notYet = (label) => () => showBanner(`${label} isn't wired up yet — that's step 4.`);
    document.getElementById("mic-btn").addEventListener("click", notYet("Voice"));
    document.getElementById("mute-btn").addEventListener("click", notYet("Mute"));
  }

  async function boot() {
    rotateExamplePrompt();
    wireButtons();

    let data;
    try {
      const res = await fetch("/api/graph");
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      data = await res.json();
    } catch (err) {
      showBanner("Can't reach the JARVIS server — is agent/main.py running?", true);
      return;
    }

    modeBadge.textContent = data.mode || "DEMO";
    renderFilters(data.nodes);

    graphHandle = window.JarvisGraph.mount(canvas, data, {
      onFocus: renderInspector,
      onPathTrace: renderPathTrace,
    });

    renderHubs(data.nodes, graphHandle);

    document.getElementById("fit-btn").addEventListener("click", () => graphHandle.fit());
    document.getElementById("labels-btn").addEventListener("click", (e) => {
      e.target.classList.toggle("active");
      graphHandle.setLabels(e.target.classList.contains("active"));
    });
  }

  boot();
})();
