/* graph.js — canvas force-directed graph.
 *
 * No frameworks, no deps. Exposes `window.JarvisGraph.mount(canvas, data, opts)`.
 * data = { nodes: [{id,title,type,degree,preview}], edges: [[a,b], ...] }
 * opts.onFocus(node|null), opts.onPathTrace(nodeArray|null)
 *
 * Perf note: repulsion uses a spatial grid with a distance cutoff so cost
 * stays near-linear instead of O(n^2) — matters once a vault has 1,500+ notes.
 */
(function () {
  const TYPE_COLORS = {
    Call:     "#5B8DEF",
    Note:     "#D8D8DC",
    Concept:  "#E8A33D",
    Project:  "#8B5CF6",
    Person:   "#C084FC",
    Client:   "#EC4899",
    Invoice:  "#F97316",
    Proposal: "#D97706",
    Sop:      "#22C55E",
    Brief:    "#9CA3AF",
    Campaign: "#4B5563",
  };
  const DEFAULT_COLOR = "#6B7280";

  const REPULSION_CUTOFF = 140;   // px — nodes beyond this ignore each other
  const REPULSION_K = 2600;
  const SPRING_LEN = 78;
  const SPRING_K = 0.02;
  const CENTER_PULL = 0.0006;
  const DAMPING = 0.86;
  const BREATH_JITTER = 0.06;     // tiny residual motion so a settled graph still "breathes"
  const PULSE_INTERVAL_MS = 2600;
  const PULSE_DURATION_MS = 950;

  function colorFor(type) {
    return TYPE_COLORS[type] || DEFAULT_COLOR;
  }

  function radiusFor(degree) {
    return Math.max(4, Math.min(26, 4 + Math.sqrt(degree) * 2.6));
  }

  class Grid {
    constructor(cell) {
      this.cell = cell;
      this.map = new Map();
    }
    key(x, y) {
      return `${Math.floor(x / this.cell)}:${Math.floor(y / this.cell)}`;
    }
    clear() { this.map.clear(); }
    insert(node) {
      const k = this.key(node.x, node.y);
      if (!this.map.has(k)) this.map.set(k, []);
      this.map.get(k).push(node);
    }
    nearby(node) {
      const cx = Math.floor(node.x / this.cell);
      const cy = Math.floor(node.y / this.cell);
      const out = [];
      for (let dx = -1; dx <= 1; dx++) {
        for (let dy = -1; dy <= 1; dy++) {
          const bucket = this.map.get(`${cx + dx}:${cy + dy}`);
          if (bucket) out.push(...bucket);
        }
      }
      return out;
    }
  }

  function bfsPath(adj, startId, endId) {
    if (startId === endId) return [startId];
    const visited = new Set([startId]);
    const prev = new Map();
    const queue = [startId];
    while (queue.length) {
      const cur = queue.shift();
      for (const next of adj.get(cur) || []) {
        if (visited.has(next)) continue;
        visited.add(next);
        prev.set(next, cur);
        if (next === endId) {
          const path = [endId];
          let n = endId;
          while (prev.has(n)) { n = prev.get(n); path.push(n); }
          return path.reverse();
        }
        queue.push(next);
      }
    }
    return null;
  }

  function mount(canvas, data, opts) {
    opts = opts || {};
    const ctx = canvas.getContext("2d");
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    const nodes = data.nodes.map((n, i) => ({
      ...n,
      x: (Math.random() - 0.5) * 600,
      y: (Math.random() - 0.5) * 600,
      vx: 0, vy: 0,
      fx: null, fy: null, // fixed position while user-dragged
      r: radiusFor(n.degree || 0),
      color: colorFor(n.type),
    }));
    const byId = new Map(nodes.map((n) => [n.id, n]));
    const edges = data.edges
      .map(([a, b]) => [byId.get(a), byId.get(b)])
      .filter(([a, b]) => a && b);

    const adj = new Map();
    for (const n of nodes) adj.set(n.id, []);
    for (const [a, b] of edges) {
      adj.get(a.id).push(b.id);
      adj.get(b.id).push(a.id);
    }

    let view = { x: 0, y: 0, scale: 1 };
    let hovered = null;
    let focused = null;
    let pathTraceFrom = null;
    let pathNodes = null;    // Set of ids on the traced path
    let pathEdgeSet = null;  // Set of "a|b" strings
    let dragging = null;     // node being dragged
    let panning = false;
    let panStart = null;
    let labelsMode = true;
    let alpha = 1;           // simulation "heat" — cools over time, never to zero

    let pulse = null; // { edge:[a,b], start:timestamp }

    function resize() {
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
    }
    resize();
    window.addEventListener("resize", resize);

    function screenToWorld(sx, sy) {
      const rect = canvas.getBoundingClientRect();
      const cx = (sx - rect.left) * dpr;
      const cy = (sy - rect.top) * dpr;
      return {
        x: (cx - canvas.width / 2) / view.scale - view.x,
        y: (cy - canvas.height / 2) / view.scale - view.y,
      };
    }

    function nodeAt(sx, sy) {
      const w = screenToWorld(sx, sy);
      let best = null, bestD = Infinity;
      for (const n of nodes) {
        const d = Math.hypot(n.x - w.x, n.y - w.y);
        if (d < n.r + 6 && d < bestD) { best = n; bestD = d; }
      }
      return best;
    }

    // ---- physics ----
    function step() {
      alpha = Math.max(0.04, alpha * 0.996); // cools, but never fully stops (breathing)
      const grid = new Grid(REPULSION_CUTOFF);
      for (const n of nodes) grid.insert(n);

      for (const n of nodes) {
        if (n.fx != null) continue;
        let fx = 0, fy = 0;
        for (const other of grid.nearby(n)) {
          if (other === n) continue;
          let dx = n.x - other.x, dy = n.y - other.y;
          let d2 = dx * dx + dy * dy;
          if (d2 < 1) d2 = 1;
          const d = Math.sqrt(d2);
          if (d > REPULSION_CUTOFF) continue;
          const force = REPULSION_K / d2;
          fx += (dx / d) * force;
          fy += (dy / d) * force;
        }
        fx -= n.x * CENTER_PULL * 60;
        fy -= n.y * CENTER_PULL * 60;
        n.vx = (n.vx + fx * 0.02) * DAMPING;
        n.vy = (n.vy + fy * 0.02) * DAMPING;
      }

      for (const [a, b] of edges) {
        const dx = b.x - a.x, dy = b.y - a.y;
        const d = Math.max(1, Math.hypot(dx, dy));
        const stretch = d - SPRING_LEN;
        const fx = (dx / d) * stretch * SPRING_K;
        const fy = (dy / d) * stretch * SPRING_K;
        if (a.fx == null) { a.vx += fx; a.vy += fy; }
        if (b.fx == null) { b.vx -= fx; b.vy -= fy; }
      }

      for (const n of nodes) {
        if (n.fx != null) { n.x = n.fx; n.y = n.fy; continue; }
        n.x += n.vx * alpha + (Math.random() - 0.5) * BREATH_JITTER;
        n.y += n.vy * alpha + (Math.random() - 0.5) * BREATH_JITTER;
      }
    }

    // ---- idle pulse ----
    function maybeStartPulse(now) {
      if (pulse && now - pulse.start < PULSE_DURATION_MS) return;
      if (!edges.length) return;
      if (Math.random() < 0.5 && pulse) return; // don't always immediately restart
      const edge = edges[Math.floor(Math.random() * edges.length)];
      pulse = { edge, start: now };
    }

    // ---- render ----
    function draw(now) {
      ctx.save();
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.translate(canvas.width / 2, canvas.height / 2);
      ctx.scale(view.scale, view.scale);
      ctx.translate(view.x, view.y);

      const highlightSet = hovered ? new Set([hovered.id, ...adj.get(hovered.id)]) : null;
      const focusSet = focused ? new Set([focused.id, ...adj.get(focused.id)]) : null;
      const dimActive = !!(highlightSet || focusSet || pathNodes);

      // edges
      ctx.lineWidth = 1 / view.scale;
      for (const [a, b] of edges) {
        let opacity = dimActive ? 0.06 : 0.16;
        let strokeStyle = "rgba(150,160,180,1)";
        const key1 = a.id + "|" + b.id, key2 = b.id + "|" + a.id;
        if (pathEdgeSet && (pathEdgeSet.has(key1) || pathEdgeSet.has(key2))) {
          opacity = 1; strokeStyle = "rgba(255,255,255,1)";
        } else if (highlightSet && highlightSet.has(a.id) && highlightSet.has(b.id)) {
          opacity = 0.7;
        } else if (focusSet && focusSet.has(a.id) && focusSet.has(b.id)) {
          opacity = 0.55;
        }
        ctx.globalAlpha = opacity;
        ctx.strokeStyle = strokeStyle;
        ctx.beginPath();
        ctx.moveTo(a.x, a.y);
        ctx.lineTo(b.x, b.y);
        ctx.stroke();
      }
      ctx.globalAlpha = 1;

      // idle pulse dot
      if (pulse) {
        const t = (now - pulse.start) / PULSE_DURATION_MS;
        if (t <= 1) {
          const [a, b] = pulse.edge;
          const ease = t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
          const px = a.x + (b.x - a.x) * ease;
          const py = a.y + (b.y - a.y) * ease;
          ctx.globalAlpha = 1 - Math.abs(t - 0.5) * 0.6;
          ctx.fillStyle = "#7DD3FC";
          ctx.beginPath();
          ctx.arc(px, py, 2.4 / Math.sqrt(view.scale), 0, Math.PI * 2);
          ctx.fill();
          ctx.globalAlpha = 1;
        }
      }

      // nodes — draw most-connected first so labels prioritize hubs
      const sorted = [...nodes].sort((a, b) => (b.degree || 0) - (a.degree || 0));
      const placedLabelBoxes = [];

      for (const n of sorted) {
        let opacity = 1;
        if (dimActive) {
          const inHighlight = highlightSet && highlightSet.has(n.id);
          const inFocus = focusSet && focusSet.has(n.id);
          const inPath = pathNodes && pathNodes.has(n.id);
          opacity = (inHighlight || inFocus || inPath) ? 1 : 0.1;
        }
        ctx.globalAlpha = opacity;

        const isLifted = hovered === n || focused === n;
        const r = isLifted ? n.r * 1.25 : n.r;

        if (isLifted) {
          ctx.shadowColor = n.color;
          ctx.shadowBlur = 18;
        } else {
          ctx.shadowBlur = 0;
        }

        ctx.fillStyle = n.color;
        ctx.beginPath();
        ctx.arc(n.x, n.y, r, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;

        if (pathNodes && pathNodes.has(n.id)) {
          ctx.strokeStyle = "#ffffff";
          ctx.lineWidth = 1.5 / view.scale;
          ctx.stroke();
        }

        // label — only for hubs / lifted / focused, with collision skip
        const wantsLabel = isLifted || (n.degree || 0) >= 6;
        if (wantsLabel && opacity > 0.5) {
          const fontSize = 11 / view.scale;
          ctx.font = `${fontSize}px -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif`;
          const label = n.title.length > 28 ? n.title.slice(0, 27) + "…" : n.title;
          const w = ctx.measureText(label).width;
          const lx = n.x + r + 6 / view.scale;
          const ly = n.y + fontSize * 0.35;
          const box = { x1: lx, y1: ly - fontSize, x2: lx + w, y2: ly + 4 / view.scale };
          const collides = placedLabelBoxes.some(
            (b) => !(box.x2 < b.x1 || box.x1 > b.x2 || box.y2 < b.y1 || box.y1 > b.y2)
          );
          if (!collides) {
            placedLabelBoxes.push(box);
            ctx.fillStyle = "rgba(226,232,240,0.92)";
            ctx.fillText(label, lx, ly);
          }
        }
      }
      ctx.globalAlpha = 1;
      ctx.restore();
    }

    let raf = null;
    function loop(now) {
      step();
      maybeStartPulse(now);
      draw(now);
      raf = requestAnimationFrame(loop);
    }
    raf = requestAnimationFrame(loop);

    // ---- interaction (mouse + touch share the same logic) ----
    let touchMode = null;    // "pan" | "drag" | "pinch" | null
    let pinchStartDist = 0;
    let pinchStartScale = 1;
    let lastTapTime = 0;
    let lastTapNode = null;
    let moved = false; // distinguishes a tap from a drag on touch

    function pointerDown(x, y) {
      moved = false;
      const n = nodeAt(x, y);
      if (n) {
        dragging = n;
        alpha = Math.max(alpha, 0.5);
      } else {
        panning = true;
        panStart = { x, y };
      }
    }

    function pointerMove(x, y) {
      if (dragging) {
        moved = true;
        const w = screenToWorld(x, y);
        dragging.fx = w.x; dragging.fy = w.y;
        return;
      }
      if (panning) {
        moved = true;
        const dx = (x - panStart.x) * dpr / view.scale;
        const dy = (y - panStart.y) * dpr / view.scale;
        view.x += dx; view.y += dy;
        panStart = { x, y };
        return;
      }
      const n = nodeAt(x, y);
      if (n !== hovered) {
        hovered = n;
        canvas.style.cursor = n ? "pointer" : "grab";
      }
    }

    function pointerUp() {
      dragging = null;
      panning = false;
      canvas.style.cursor = hovered ? "pointer" : "grab";
    }

    function handleTap(x, y, shiftKey) {
      const n = nodeAt(x, y);
      if (!n) {
        focused = null; pathTraceFrom = null; pathNodes = null; pathEdgeSet = null;
        opts.onFocus && opts.onFocus(null);
        return;
      }
      if (shiftKey && focused) {
        pathTraceFrom = focused;
        const path = bfsPath(adj, focused.id, n.id);
        if (path && path.length) {
          pathNodes = new Set(path);
          pathEdgeSet = new Set();
          for (let i = 0; i < path.length - 1; i++) {
            pathEdgeSet.add(path[i] + "|" + path[i + 1]);
          }
          opts.onPathTrace && opts.onPathTrace(path.map((id) => byId.get(id)));
        } else {
          pathNodes = null; pathEdgeSet = null;
          opts.onPathTrace && opts.onPathTrace(null);
        }
        return;
      }
      focused = n;
      pathNodes = null; pathEdgeSet = null; pathTraceFrom = null;
      opts.onFocus && opts.onFocus(n);
    }

    // -- mouse --
    canvas.addEventListener("mousemove", (e) => pointerMove(e.clientX, e.clientY));
    canvas.addEventListener("mousedown", (e) => pointerDown(e.clientX, e.clientY));
    window.addEventListener("mouseup", () => pointerUp());
    canvas.addEventListener("click", (e) => {
      if (moved) { moved = false; return; } // a drag that just ended shouldn't also fire a click-focus
      handleTap(e.clientX, e.clientY, e.shiftKey);
    });
    canvas.addEventListener("wheel", (e) => {
      e.preventDefault();
      const factor = e.deltaY > 0 ? 0.9 : 1.1;
      view.scale = Math.max(0.15, Math.min(4, view.scale * factor));
    }, { passive: false });

    // -- touch: one finger pans/drags/taps, two fingers pinch-zoom --
    function touchDist(t0, t1) {
      return Math.hypot(t1.clientX - t0.clientX, t1.clientY - t0.clientY);
    }
    function touchMid(t0, t1) {
      return { x: (t0.clientX + t1.clientX) / 2, y: (t0.clientY + t1.clientY) / 2 };
    }

    canvas.addEventListener("touchstart", (e) => {
      e.preventDefault();
      if (e.touches.length === 2) {
        touchMode = "pinch";
        dragging = null; panning = false;
        pinchStartDist = touchDist(e.touches[0], e.touches[1]);
        pinchStartScale = view.scale;
      } else if (e.touches.length === 1) {
        touchMode = "single";
        const t = e.touches[0];
        pointerDown(t.clientX, t.clientY);
      }
    }, { passive: false });

    canvas.addEventListener("touchmove", (e) => {
      e.preventDefault();
      if (touchMode === "pinch" && e.touches.length === 2) {
        const d = touchDist(e.touches[0], e.touches[1]);
        view.scale = Math.max(0.15, Math.min(4, pinchStartScale * (d / pinchStartDist)));
        return;
      }
      if (touchMode === "single" && e.touches.length === 1) {
        const t = e.touches[0];
        pointerMove(t.clientX, t.clientY);
      }
    }, { passive: false });

    canvas.addEventListener("touchend", (e) => {
      e.preventDefault();
      const wasSingleTap = touchMode === "single" && !moved;
      if (wasSingleTap) {
        const t = e.changedTouches[0];
        const now = Date.now();
        const isDoubleTap = now - lastTapTime < 300;
        lastTapTime = now;
        handleTap(t.clientX, t.clientY, isDoubleTap); // double-tap == shift-click path trace on touch
      }
      pointerUp();
      touchMode = e.touches.length ? "pinch" : null;
    }, { passive: false });

    return {
      fit() {
        view = { x: 0, y: 0, scale: 1 };
      },
      focusById(id) {
        const n = byId.get(id);
        if (n) { focused = n; opts.onFocus && opts.onFocus(n); }
      },
      clearFocus() {
        focused = null; pathNodes = null; pathEdgeSet = null;
        opts.onFocus && opts.onFocus(null);
      },
      setLabels(on) { labelsMode = on; },
      destroy() {
        cancelAnimationFrame(raf);
        window.removeEventListener("resize", resize);
      },
    };
  }

  window.JarvisGraph = { mount, colorFor, TYPE_COLORS };
})();
