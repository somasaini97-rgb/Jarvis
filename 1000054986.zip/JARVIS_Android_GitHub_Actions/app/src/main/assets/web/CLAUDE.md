# Who I am

**STILL PLACEHOLDER.** JARVIS was built before real business details were
given — fill in the sections below with the real thing before running
against your actual folders (JARVIS_DEMO=0). Everything here also lives
in `agent/data.py` under `BUSINESS`, which is what the tools actually read.

- **Name:** Daksh
- **Business:** _(not given yet — one line: what you do, who for)_
- **What I sell, and for how much:** _(not given yet — real numbers, even rough)_
- **Real clients:** _(not given yet — 2-3 names, replacing the demo fixtures'
  Filect / Northbeam Automation / etc.)_
- **How I want to be spoken to:** _(not given yet — defaulting to short, dry,
  no preamble, lead with the number or name, never "Absolutely" or "Great
  question," say "don't know" in four words if you don't know)_

# Folders to index (JARVIS_DEMO=0)

None set yet. Add real paths to `VAULT_PATHS_REAL` in `agent/data.py`.

# Notes for future-me (JARVIS)

- Demo mode (`JARVIS_DEMO=1`, the default) uses fixtures shaped like a
  small agency: 9 clients, projects, calls, invoices, proposals, SOPs.
  Safe to screen-record. Don't treat anything in it as real.
- `read_inbox` and `brief_me` only work in demo mode right now — no real
  email/calendar integration has been built or authorized yet.
- `research_web` currently answers from the model's general knowledge, not
  a live web search — no search API key has been wired up.
