# JARVIS Android + GitHub Actions APK Builder

1. Create a GitHub repository.
2. Upload the contents of this folder to the repository root.
3. Open **Actions** → **Build JARVIS Android APK**.
4. Click **Run workflow**.
5. When it finishes, open the workflow run and download **JARVIS-debug-APK** under Artifacts.
6. Extract the artifact and install `app-debug.apk` on your Android phone.

The workflow builds the APK on a GitHub-hosted runner using Gradle and uploads the APK as an artifact.

Note: if JARVIS needs a Python backend, `localhost` on the phone is not the same as your computer. Use a reachable HTTPS/LAN backend URL.
